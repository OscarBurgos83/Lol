
# LOL Comedy Showcase

A fast, modern, mobile-friendly site to promote shows, list tour dates, sell tickets, and feature comedians — plus a page for performer submissions.

## What's Inside
- **index.html** — Home / overview
- **shows.html** — Auto-renders from `assets/js/shows.json`
- **comedians.html** — Featured comics (edit copy)
- **tickets.html** — Quick links to purchase
- **performers.html** — Submission form (mailto)
- **contact.html** — Partners & general contact
- **assets/js/shows.json** — Edit tour dates here
- **assets/css/styles.css** — Theme & layout
- **assets/img/logo.svg** — Simple logo (swap in your real logo anytime)

## Quick Edit
- Update shows in `assets/js/shows.json` (ISO date `YYYY-MM-DD`).
- Replace ticket URLs with real links (Eventbrite, Ticketmaster, Square, etc.).
- Swap `assets/img/logo.svg` with your own logo file (same name for easiest replacement).

## Deploy
- **Netlify**: drag-and-drop the folder, or connect a repo.
- **GitHub Pages**: push these files and enable Pages.
- **Any Host**: upload as-is; it's plain HTML/CSS/JS.

## Custom Domains
Point your domain's A/CNAME to your host. Add `www` and apex.

## Forms (optional)
For a database-backed performer form, replace the mailto with: Netlify Forms, Tally, Typeform, Airtable, or Google Forms and embed their script.

---

**Made for Chicago — with love and big laughs.**
