
async function loadShows() {
  try {
    const res = await fetch('assets/js/shows.json');
    const shows = await res.json();
    const list = document.getElementById('shows-list');
    if (!list) return;
    list.innerHTML = '';

    const url = new URL(window.location.href);
    const city = url.searchParams.get('city') || 'Chicago';

    document.getElementById('city-filter')?.setAttribute('value', city);

    shows
      .filter(s => !city || s.city.toLowerCase().includes(city.toLowerCase()))
      .sort((a,b)=> new Date(a.date) - new Date(b.date))
      .forEach(s => {
        const d = new Date(s.date + 'T19:00:00');
        const dow = d.toLocaleDateString(undefined, { weekday: 'short' });
        const dom = d.getDate();
        const month = d.toLocaleDateString(undefined, { month: 'short' });
        const el = document.createElement('div');
        el.className = 'show-row';
        el.innerHTML = `
          <div class="show-date">
            <div class="dow">${dow}</div>
            <div class="dom">${month} ${dom}</div>
          </div>
          <div class="show-info">
            <h3>${s.title}</h3>
            <div class="meta">${s.venue} • ${s.city} • ${s.time}</div>
            <div class="meta">Featuring: ${s.comedians.join(', ')}</div>
            <div style="margin-top:8px; display:flex; gap:10px; flex-wrap:wrap;">
              <a class="btn buy" href="${s.ticket_url}" target="_blank" rel="noopener">Buy Tickets</a>
              <span class="tag">${s.age_restriction || 'All Ages'}</span>
              <span class="tag">${s.format || 'Stand-Up'}</span>
            </div>
          </div>
        `;
        list.appendChild(el);
      });
  } catch (e) {
    console.error(e);
  }
}

function handlePerformerForm() {
  const form = document.getElementById('performer-form');
  if (!form) return;
  form.addEventListener('submit', (e)=>{
    // Just build a mailto for now
    e.preventDefault();
    const data = new FormData(form);
    const entries = Object.fromEntries(data.entries());
    const lines = Object.entries(entries).map(([k,v]) => `${k}: ${v}`).join('%0D%0A');
    const subject = encodeURIComponent('Performer Submission – LOL Comedy Showcase');
    const body = lines + '%0D%0A%0D%0A' + 'Submitted from the website.';
    window.location.href = `mailto:o.burgos@sbcglobal.net?subject=${subject}&body=${body}`;
  });
}

document.addEventListener('DOMContentLoaded', ()=>{
  loadShows();
  handlePerformerForm();
});
